# Correct bladeRF baseline

Base: passive-bladerf-100MHz, commit 5828211131774e5f0ac199b3406de4e7dc61d3b1,
from /home/sens/NICOLA/oai-passive-bladerf-orig.
This branch already descends from adaptive-rx-UL-DL (3ca9a174e9).
Original worktrees and device firmware/FPGA are unchanged.

The receiver and RF driver are initially unchanged from that baseline.
Do not import the old branch's second clock-drift/CFO implementation:
the adaptive receiver already has its own timing tracker and initial CFO seed.

Build:
```sh
cmake -S . -B cmake_targets/ran_build/build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DOAI_BLADERF=ON -DOAI_USRP=OFF -DENABLE_ISAC_SENSING=ON -DENABLE_TESTS=OFF
cmake --build cmake_targets/ran_build/build --target nr-uesoftmodem oai_bladerfdevif params_libconfig coding ldpc dfts -j6
```

Run:
```sh
bash tests/passive_rx/run_bladerf_capture.sh baseline
bash tests/passive_rx/run_bladerf_capture.sh full
```

One RX1 antenna, no RF TX, 122.88 Msps SC8, 3.45 GHz, 273 PRB, gain 32.
The -4.21 ppm timing seed reproduces the branch's recorded passive measurement;
it is a baseline reproduction value, not a new online calibration.
The initial CPU mask excludes USB IRQ CPU 10; RX runs on CPU 4.
Stop the previous capture's dashboard before starting another on port 8082.
The dashboard remains after a capture ends; that is not evidence of live RF.
The baseline mode is SIB1-only and does not measure UL. Full mode enables the
baseline's dedicated DL/UL/CSI-RS configuration.

The baseline's commit notes report 100% SIB1, NOT >90% dedicated DL and UL.
Dedicated PDSCH and PUSCH remain to be measured and fixed.
No CRC result is valid when RF continuity fails.
DMRS and CSI-RS are reference signals, not CRC-bearing messages.

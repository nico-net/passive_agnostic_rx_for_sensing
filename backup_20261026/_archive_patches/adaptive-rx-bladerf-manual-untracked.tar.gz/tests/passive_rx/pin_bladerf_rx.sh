#!/bin/bash
set -u
taskset -c 0,1,4,8,9 "$@" &
child=$!
stop_child() {
  kill -INT "$child" 2>/dev/null || true
  for i in $(seq 1 30); do kill -0 "$child" 2>/dev/null || break; sleep .1; done
  kill -KILL "$child" 2>/dev/null || true
  wait "$child" 2>/dev/null || true
  exit 143
}
trap stop_child TERM INT
for i in $(seq 1 1800); do
  kill -0 "$child" 2>/dev/null || { wait "$child"; exit $?; }
  tid=$(ps -T -p "$child" -o tid=,comm= | awk '$2 == "UEthread_0" {print $1; exit}')
  if [ -n "$tid" ]; then taskset -pc 4 "$tid"; break; fi
  sleep .05
done
wait "$child"

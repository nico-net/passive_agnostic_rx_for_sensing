#!/bin/bash
set -euo pipefail
repo=$(cd "$(dirname "$0")/../.." && pwd)
build="$repo/cmake_targets/ran_build/build"
mode=${1:-full}
case "$mode" in
  baseline) config="$repo/tests/passive_rx/ota/nrue.passive_rx.bladerf.coreset0.conf"; duration=120 ;;
  full) config="$repo/tests/passive_rx/ota/nrue.passive_rx.bladerf.full_all.conf"; duration=3600 ;;
  *) printf 'Usage: %s baseline|full [capture-directory]\n' "$0"; exit 2 ;;
esac
out=${2:-$(mktemp -d "$HOME/NICOLA/captures/bladerf_${mode}.XXXXXX")}
mkdir -p "$out"
exec 9>/tmp/adaptive-rx-bladerf.radio.lock
flock -n 9 || { printf 'bladeRF capture already active\n'; exit 3; }
if ps -eo stat=,comm= | awk '$2 == "nr-uesoftmodem" && $1 !~ /^Z/ {f=1} END {exit !f}'; then
  printf 'Refusing concurrent receiver\n'; exit 3
fi
cp "$config" "$out/receiver.conf"
sha256sum "$build/nr-uesoftmodem" "$build/liboai_bladerfdevif.so" "$out/receiver.conf" > "$out/checksums.txt"
printf '%s\n' "$out" > /tmp/codex_bladerf_dashboard_capture
nohup python3 "$repo/tests/passive_rx/monitor/monitor.py" --connect tcp://127.0.0.1:5557 --log "$out/run.log" --port 8082 --bind 127.0.0.1 > "$out/dashboard.log" 2>&1 < /dev/null 9>&- &
printf '%s\n' "$!" > "$out/dashboard.pid"
printf 'RUNNING_UNVALIDATED\n' > "$out/measurement_validity.txt"
printf 'CAPTURE=%s MODE=%s DASHBOARD=http://localhost:8082/\n' "$out" "$mode"
cd "$build"
set +e
sudo -n env -i PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
 LD_LIBRARY_PATH="$build:/usr/local/lib:/usr/lib/x86_64-linux-gnu" \
 ISAC_RX_MRC_MODE=0 ISAC_UL_RX_BRANCH=0 ISAC_DMRS_FO_APPLY=0 ISAC_SFO_CORRECT=0 \
 ISAC_RX_BRANCH_FO=0 ISAC_RX_GAIN_TRIM=0 ISAC_DISC_NO_RESYNC=0 ISAC_RF_STALL_MAX_REINIT=0 \
 ISAC_CFO_TRACK_HZ=0 ISAC_PDCCH_TIMING=1 ISAC_PUSCH_TIMING=1 ISAC_PUSCH_DIAG=1 \
 ISAC_UL_TA_SWEEP=0:0:0 ISAC_TSYNC_RESET=0 \
 timeout --signal=TERM --kill-after=5s "${duration}s" bash "$repo/tests/passive_rx/pin_bladerf_rx.sh" \
 "$build/nr-uesoftmodem" -O "$out/receiver.conf" \
 --usrp-args '*:serial=b1e14bf73dfd46d5838d0b003117480d' \
 -r 273 --numerology 1 --band 78 -C 3450000000 --ssb 150 \
 --ue-rxgain 32 --ue-nb-ant-rx 1 --ue-nb-ant-tx 1 --ue-rx-only --passive-rx \
 --ue-fo-compensation --cont-fo-comp 0 --time-sync-I 0.01 --ntn-initial-time-drift -4.21 \
 --sync-actor-core 1 --thread-pool 0,1,6,7 -A 90 > "$out/run.log" 2>&1
rc=$?
printf '%s\n' "$rc" > "$out/process_exit.txt"
if grep -Eq 'RXDISCONT|RFSTALL|RX overrun is detected|RX failed:|RX bad samples count|Assertion.*failed|Segmentation fault|still stuck after' "$out/run.log"; then
  printf 'VOID_RF_OR_PROCESS_FAILURE\n' > "$out/measurement_validity.txt"
else
  printf 'STOPPED_UNVALIDATED_EXIT_%s\n' "$rc" > "$out/measurement_validity.txt"
fi
exit "$rc"

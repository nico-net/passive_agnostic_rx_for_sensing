# Single-antenna bladeRF manual receiver

This worktree starts from adaptive-rx-UL-DL and ports the 122.88 Msps SC8
transport from bladerf-100MHz (178ecec3c3). The original worktrees are unchanged.
The latest DL/UL discovery and UCI fixes are carried forward for later auto tests.

Build:
```sh
cmake -S . -B cmake_targets/ran_build/build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DOAI_BLADERF=ON -DOAI_USRP=OFF -DENABLE_ISAC_SENSING=ON -DENABLE_TESTS=OFF
cmake --build cmake_targets/ran_build/build --target nr-uesoftmodem oai_bladerfdevif -j6
```

Run as sens (requires passwordless sudo for USB access):
```sh
bash tests/passive_rx/run_bladerf_manual.sh
```

RF: RX1 only, 3.45 GHz, 273 PRB, numerology 1, internal clock, no TX.
Manual geometry is from the previous passive cell capture, not a live gNB feed.
Do not reuse the X410's CFO or sample-clock drift. Acquisition measures bladeRF CFO;
PBCH timing feedback tracks the remaining timing error.
USB IRQ CPU 10 is excluded from the worker and inherited CPU masks.
Dashboard binds localhost:8082; reports bind localhost:5557.

Channels enabled: SSB/PBCH, PDCCH/DCI, PDSCH, PUSCH, DL/UL DMRS and configured CSI-RS.
DMRS and CSI-RS are reference signals and do not have transport-block CRCs.
This does not promise decryption of encrypted user traffic or unsupported PHY channels.
One RX antenna cannot recover arbitrary multi-layer transmissions.

Acceptance: continuous RF samples without runtime overruns/short reads/errors, advancing
dashboard counters, and measured DL and UL TB CRC above 90% over at least 60 seconds
with sufficient completed transport blocks. Queue drops remain reported separately.
No CRC claim is valid for an RF-invalid interval.
